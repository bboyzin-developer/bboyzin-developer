package com.bbs.test_bbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestBbsApplicationTests {

    @Test
    void contextLoads() {
    }

}
