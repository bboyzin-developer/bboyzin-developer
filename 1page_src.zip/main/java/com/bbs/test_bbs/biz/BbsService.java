package com.bbs.test_bbs.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BbsService {

    @Autowired
    private BbsDAO bbsDAO;

    //검색 기간내 질문 리스트 구현
    public List<BbsVO> getBbsList(BbsVO vo) {
        return bbsDAO.getBbsList(vo);
    }

    //질문건수 카운팅 구현
    public List<BbsVO> getBbsCount(BbsVO vo) {
        return bbsDAO.getBbsCount(vo);
    }
}
