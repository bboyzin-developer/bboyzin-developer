package com.bbs.test_bbs.biz;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BbsDAO {

    @Autowired
    private SqlSession sqlSession;

    public List<BbsVO> getBbsList(BbsVO vo) {
        List<BbsVO> bbsList = sqlSession.selectList("BbsDAO.getBbsList", vo);
        return bbsList;
    }

    public List<BbsVO> getBbsCount(BbsVO vo) {
        List<BbsVO> bbsCount = sqlSession.selectList("BbsDAO.getBbsCount", vo);
        return bbsCount;
    }
}
